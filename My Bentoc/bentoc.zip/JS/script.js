const nav = document.querySelector("nav");
const menuBtn = document.querySelector(".menu-toggle");
const closeBtn = document.querySelector(".menu-close");

menuBtn.addEventListener("click", function(){
    nav.classList.toggle("nav-show");
    menuBtn.classList.toggle("hide-element");
    closeBtn.classList.toggle("show-element");
})

closeBtn.addEventListener("click", function(){
    nav.classList.toggle("nav-show");
    menuBtn.classList.toggle("hide-element");
    closeBtn.classList.toggle("show-element");
})
